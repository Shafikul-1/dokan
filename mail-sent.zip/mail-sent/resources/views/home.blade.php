@extends('header')
@section('othersContent')
    <h1 class="font-bold text-4xl text-center">Home page</h1>
@endsection