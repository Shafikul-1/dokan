
<?php $__env->startSection('othersContent'); ?>
    <h1 class="font-bold text-4xl text-center">Home page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\mail-sent\resources\views/home.blade.php ENDPATH**/ ?>